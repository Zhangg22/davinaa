
/* ======================================
   DIGIWEB - JAVASCRIPT UTAMA
   ====================================== */

document.addEventListener("DOMContentLoaded", function () {

    // ==================================
    // 1. LOADING SCREEN
    // ==================================

    const loader = document.getElementById("loader");

    function hideLoader() {
        if (loader) {
            loader.classList.add("hidden");
        }
    }

    window.addEventListener("load", hideLoader);

    // Fallback jika event load sudah terjadi
    if (document.readyState === "complete") {
        hideLoader();
    }

    // ==================================
    // 2. MENU NAVIGASI MOBILE
    // ==================================

    const menuToggle = document.getElementById("menuToggle");
    const navbar = document.getElementById("navbar");
    const navLinks = document.querySelectorAll(".nav-link");

    if (menuToggle && navbar) {
        menuToggle.addEventListener("click", function () {
            const isOpen = navbar.classList.toggle("open");

            menuToggle.textContent = isOpen ? "✕" : "☰";
            menuToggle.setAttribute("aria-expanded", String(isOpen));
            menuToggle.setAttribute(
                "aria-label",
                isOpen ? "Tutup menu" : "Buka menu"
            );
        });

        navLinks.forEach(function (link) {
            link.addEventListener("click", function () {
                navbar.classList.remove("open");
                menuToggle.textContent = "☰";
                menuToggle.setAttribute("aria-expanded", "false");
            });
        });

        document.addEventListener("click", function (event) {
            if (
                !navbar.contains(event.target) &&
                !menuToggle.contains(event.target)
            ) {
                navbar.classList.remove("open");
                menuToggle.textContent = "☰";
                menuToggle.setAttribute("aria-expanded", "false");
            }
        });
    }

    // ==================================
    // 3. TAHUN OTOMATIS DI FOOTER
    // ==================================

    const yearElement = document.getElementById("year");

    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }

    // ==================================
    // 4. TEMA GELAP DAN TERANG
    // ==================================

    const themeToggle = document.getElementById("themeToggle");
    const savedTheme = localStorage.getItem("digiweb-theme");

    if (savedTheme === "dark") {
        document.body.classList.add("dark-mode");
    }

    function updateThemeButton() {
        if (!themeToggle) return;

        const darkMode = document.body.classList.contains("dark-mode");

        themeToggle.textContent = darkMode ? "☀️" : "🌙";
        themeToggle.setAttribute(
            "aria-label",
            darkMode ? "Gunakan tema terang" : "Gunakan tema gelap"
        );
    }

    updateThemeButton();

    if (themeToggle) {
        themeToggle.addEventListener("click", function () {
            document.body.classList.toggle("dark-mode");

            const currentTheme =
                document.body.classList.contains("dark-mode")
                    ? "dark"
                    : "light";

            try {
                localStorage.setItem("digiweb-theme", currentTheme);
            } catch (error) {
                console.log("Pengaturan tema tidak dapat disimpan.");
            }

            updateThemeButton();
        });
    }

    // ==================================
    // 5. ANIMASI ELEMEN SAAT SCROLL
    // ==================================

    const revealElements = document.querySelectorAll(
        ".section-heading, .about-image, .about-content, " +
        ".service-card, .gallery-card, .contact-info, .contact-form"
    );

    revealElements.forEach(function (element) {
        element.classList.add("reveal");
    });

    if ("IntersectionObserver" in window) {
        const revealObserver = new IntersectionObserver(
            function (entries, observer) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("visible");
                        observer.unobserve(entry.target);
                    }
                });
            },
            {
                threshold: 0.12
            }
        );

        revealElements.forEach(function (element) {
            revealObserver.observe(element);
        });
    } else {
        revealElements.forEach(function (element) {
            element.classList.add("visible");
        });
    }

    // ==================================
    // 6. PENGHITUNG STATISTIK
    // ==================================

    const counters = document.querySelectorAll(".counter");
    let countersStarted = false;

    function startCounters() {
        if (countersStarted) return;

        countersStarted = true;

        counters.forEach(function (counter) {
            const target = Number(counter.dataset.target) || 0;
            const duration = 1200;
            const startTime = performance.now();

            function updateCounter(currentTime) {
                const progress = Math.min(
                    (currentTime - startTime) / duration,
                    1
                );

                const easedProgress = 1 - Math.pow(1 - progress, 3);
                const currentValue = Math.floor(
                    easedProgress * target
                );

                counter.textContent = currentValue;

                if (progress < 1) {
                    requestAnimationFrame(updateCounter);
                } else {
                    counter.textContent = target;
                }
            }

            requestAnimationFrame(updateCounter);
        });
    }

    const statistics = document.querySelector(".statistics");

    if (statistics && "IntersectionObserver" in window) {
        const statsObserver = new IntersectionObserver(
            function (entries, observer) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        startCounters();
                        observer.unobserve(entry.target);
                    }
                });
            },
            {
                threshold: 0.3
            }
        );

        statsObserver.observe(statistics);
    } else {
        startCounters();
    }

    // ==================================
    // 7. TOMBOL KEMBALI KE ATAS
    // ==================================

    const backToTop = document.getElementById("backToTop");

    function handleScroll() {
        if (backToTop) {
            if (window.scrollY > 400) {
                backToTop.classList.add("show");
            } else {
                backToTop.classList.remove("show");
            }
        }

        updateActiveLink();
    }

    if (backToTop) {
        backToTop.addEventListener("click", function () {
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        });
    }

    window.addEventListener("scroll", handleScroll, {
        passive: true
    });

    handleScroll();

    // ==================================
    // 8. NAVIGASI AKTIF SESUAI SECTION
    // ==================================

    function updateActiveLink() {
        const sections = document.querySelectorAll("main section[id]");
        let currentSection = "beranda";

        sections.forEach(function (section) {
            const sectionTop = section.offsetTop - 150;

            if (window.scrollY >= sectionTop) {
                currentSection = section.id;
            }
        });

        navLinks.forEach(function (link) {
            const linkTarget = link.getAttribute("href");

            if (linkTarget === "#" + currentSection) {
                link.classList.add("active");
            } else {
                link.classList.remove("active");
            }
        });
    }

    // ==================================
    // 9. VALIDASI FORMULIR KONTAK
    // ==================================

    const contactForm = document.getElementById("contactForm");
    const formMessage = document.getElementById("formMessage");

    if (contactForm && formMessage) {
        contactForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const name = document.getElementById("name").value.trim();
            const email = document.getElementById("email").value.trim();
            const subject = document.getElementById("subject").value.trim();
            const message = document.getElementById("message").value.trim();

            if (!name || !email || !subject || !message) {
                formMessage.textContent =
                    "Mohon isi semua kolom terlebih dahulu.";
                return;
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!emailPattern.test(email)) {
                formMessage.textContent =
                    "Masukkan alamat email yang valid.";
                return;
            }

            formMessage.textContent =
                "Terima kasih, " + name +
                "! Formulir berhasil diperiksa. " +
                "Demo ini belum mengirim pesan ke server.";

            contactForm.reset();
        });
    }

    // ==================================
    // 10. EFEK HEADER SAAT SCROLL
    // ==================================

    const header = document.getElementById("header");

    function updateHeader() {
        if (!header) return;

        if (window.scrollY > 30) {
            header.style.boxShadow =
                "0 5px 25px rgba(0, 0, 0, 0.08)";
        } else {
            header.style.boxShadow =
                "0 3px 15px rgba(0, 0, 0, 0.03)";
        }
    }

    window.addEventListener("scroll", updateHeader, {
        passive: true
    });

    updateHeader();

    // ==================================
    // 11. TOMBOL TAUTAN LAYANAN
    // ==================================

    const serviceLinks = document.querySelectorAll(".service-link");

    serviceLinks.forEach(function (link) {
        link.addEventListener("click", function () {
            const serviceName =
                link.closest(".service-card").querySelector("h3").textContent;

            console.log("Layanan dipilih:", serviceName);
        });
    });

    // ==================================
    // 12. PESAN SELAMAT DATANG
    // ==================================

    console.log("DigiWeb berhasil dimuat!");
    console.log("HTML, CSS, dan JavaScript terhubung.");
});
